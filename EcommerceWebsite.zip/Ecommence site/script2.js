/////////////////////1/////////////////////////////////
const imageContainer1 = document.getElementById('span1');
const image1 = document.getElementById('img1');
const image2 = document.getElementById('img2');

imageContainer1.addEventListener('mouseenter', function() {
    image1.classList.add('hidden');
    image2.classList.remove('show');
});

imageContainer1.addEventListener('mouseleave', function() {
    image1.classList.remove('hidden');
    image2.classList.add('show');
});


/////////////////////2/////////////////////////////////
const imageContainer2 = document.getElementById('span2');
const image3 = document.getElementById('img3');
const image4 = document.getElementById('img4');

imageContainer2.addEventListener('mouseenter', function() {
    image3.classList.add('hidden');
    image4.classList.remove('show');
});

imageContainer2.addEventListener('mouseleave', function() {
    image3.classList.remove('hidden');
    image4.classList.add('show');
});


/////////////////////3/////////////////////////////////
const imageContainer3 = document.getElementById('span3');
const image5 = document.getElementById('img5');
const image6 = document.getElementById('img6');

imageContainer3.addEventListener('mouseenter', function() {
    image5.classList.add('hidden');
    image6.classList.remove('show');
});

imageContainer3.addEventListener('mouseleave', function() {
    image5.classList.remove('hidden');
    image6.classList.add('show');
});


/////////////////////4/////////////////////////////////
const imageContainer4 = document.getElementById('span4');
const image7 = document.getElementById('img7');
const image8 = document.getElementById('img8');

imageContainer4.addEventListener('mouseenter', function() {
    image7.classList.add('hidden');
    image8.classList.remove('show');
});

imageContainer4.addEventListener('mouseleave', function() {
    image7.classList.remove('hidden');
    image8.classList.add('show');
});


/////////////////////5/////////////////////////////////
const imageContainer5 = document.getElementById('span5');
const image9 = document.getElementById('img9');
const image10 = document.getElementById('img10');

imageContainer5.addEventListener('mouseenter', function() {
    image9.classList.add('hidden');
    image10.classList.remove('show');
});

imageContainer5.addEventListener('mouseleave', function() {
    image9.classList.remove('hidden');
    image10.classList.add('show');
});


/////////////////////6/////////////////////////////////
const imageContainer6 = document.getElementById('span6');
const image11 = document.getElementById('img11');
const image12 = document.getElementById('img12');

imageContainer6.addEventListener('mouseenter', function() {
    image11.classList.add('hidden');
    image12.classList.remove('show');
});

imageContainer6.addEventListener('mouseleave', function() {
    image11.classList.remove('hidden');
    image12.classList.add('show');
});


/////////////////////7/////////////////////////////////
const imageContainer7 = document.getElementById('span7');
const image13 = document.getElementById('img13');
const image14 = document.getElementById('img14');

imageContainer7.addEventListener('mouseenter', function() {
    image13.classList.add('hidden');
    image14.classList.remove('show');
});

imageContainer7.addEventListener('mouseleave', function() {
    image13.classList.remove('hidden');
    image14.classList.add('show');
});


/////////////////////8/////////////////////////////////
const imageContainer8 = document.getElementById('span8');
const image15 = document.getElementById('img15');
const image16 = document.getElementById('img16');

imageContainer8.addEventListener('mouseenter', function() {
    image15.classList.add('hidden');
    image16.classList.remove('show');
});

imageContainer8.addEventListener('mouseleave', function() {
    image15.classList.remove('hidden');
    image16.classList.add('show');
});


/////////////////////9/////////////////////////////////
const imageContainer9 = document.getElementById('span9');
const image17 = document.getElementById('img17');
const image18 = document.getElementById('img18');

imageContainer9.addEventListener('mouseenter', function() {
    image17.classList.add('hidden');
    image18.classList.remove('show');
});

imageContainer9.addEventListener('mouseleave', function() {
    image17.classList.remove('hidden');
    image18.classList.add('show');
});


/////////////////////10/////////////////////////////////
const imageContainer10 = document.getElementById('span10');
const image19 = document.getElementById('img19');
const image20 = document.getElementById('img20');

imageContainer10.addEventListener('mouseenter', function() {
    image19.classList.add('hidden');
    image20.classList.remove('show');
});

imageContainer10.addEventListener('mouseleave', function() {
    image19.classList.remove('hidden');
    image20.classList.add('show');
});


/////////////////////11/////////////////////////////////
const imageContainer11 = document.getElementById('span11');
const image21 = document.getElementById('img21');
const image22 = document.getElementById('img22');

imageContainer11.addEventListener('mouseenter', function() {
    image21.classList.add('hidden');
    image22.classList.remove('show');
});

imageContainer11.addEventListener('mouseleave', function() {
    image21.classList.remove('hidden');
    image22.classList.add('show');
});


/////////////////////12/////////////////////////////////
const imageContainer12 = document.getElementById('span12');
const image23 = document.getElementById('img23');
const image24 = document.getElementById('img24');

imageContainer12.addEventListener('mouseenter', function() {
    image23.classList.add('hidden');
    image24.classList.remove('show');
});

imageContainer12.addEventListener('mouseleave', function() {
    image23.classList.remove('hidden');
    image24.classList.add('show');
});



